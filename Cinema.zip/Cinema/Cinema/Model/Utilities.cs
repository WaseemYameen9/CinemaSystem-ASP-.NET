﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Cinema.Model
{
    public class Utilities
    {
        public static int loginer;
    }
}